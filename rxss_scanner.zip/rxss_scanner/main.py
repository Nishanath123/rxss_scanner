
from scanner.engine import XSSScanner

if __name__ == "__main__":
    
    scanner = XSSScanner(
        url="http://testphp.vulnweb.com/search.php",
        parameters=["searchFor", "uname", "query"],
        method="GET"
    )
    scanner.scan()

    print("\nScan complete.")
    print("HTML report generated: vipratech_report.html")