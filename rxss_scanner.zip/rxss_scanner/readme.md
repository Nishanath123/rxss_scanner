# VipraTech – Reflected XSS Scanner

    This project is my submission for the VipraTech Security Engineer (Python – Tooling & Integrations) assignment.  
    The tool checks for reflected XSS by injecting payloads into parameters and then looking for the marker in the HTML response.  
    I kept the code simple and understandable.

# What this project is

    A small Python tool that checks for Reflected XSS by injecting context-aware payloads into given parameters and looking for a marker in the HTTP response. It supports GET and POST, runs requests in parallel, guesses the context of reflections, and writes an HTML report.

    This fulfills the assignment requirements:

    PayloadGenerator class with context-specific payloads (including attribute-name).

    Reflection detection using a marker string.

    Supports GET and POST.

    Generates an HTML report and prints a terminal summary.

    Uses threads for parallel scanning and accepts headers/cookies.

## 1. Assumptions I Made

    1. This tool only checks for reflected XSS, not stored or DOM-based.
    2. The target URL returns HTML responses.
    3. Payload reflections are detected by a unique marker (`VIPRA_XSS_9797`).
    4. I did not use a headless browser — only raw HTML scanning.
    5. The scanner requires valid parameter names to test.
    6. For the assignment, testing 3 or more contexts is enough.

# Project Files and structure

    ![alt text](image.png)
    RXSS_SCANNER/
│
├── renv/                    # Virtual environment (local) — 
│
├── scanner/
│   ├── __pycache__/         # Python cache files (auto-generated)
│   │
│   ├── detector.py          # ReflectionDetector:
│   │                          # - Looks for the payload marker in the HTTP response HTML
│   │                          # - Extracts a small snippet around the marker
│   │                          # - Uses BeautifulSoup to guess context (script, attribute-name,
│   │                          #   attribute-value, tag, or text)
│   │                          # - Returns a dict with reflected True/False, context, snippet
│   │
│   ├── engine.py            # XSSScanner (orchestration):
│   │                          # - Loads payloads from PayloadGenerator
│   │                          # - Iterates parameters and payloads, sends HTTP requests (GET/POST)
│   │                          # - Uses ThreadPoolExecutor for parallel requests
│   │                          # - Calls ReflectionDetector to check responses
│   │                          # - Collects findings and passes them to reporter
│   │
│   ├── payloads.py         # PayloadGenerator:
│   │                          # - Holds payloads grouped by context:
│   │                          #   text, attribute_value, attribute_name, js_string, tag_name
│   │                          # - Inserts a unique marker (e.g., VIPRA_XSS_9797) into each payload
│   │                          # - Provides methods: for_context(context), all_payloads(), get_marker()
│   │
│   ├── reporter.py         # Reporter:
│   │                          # - Renders findings to an HTML report using Jinja2 template
│   │                          # - Writes vipratech_report.html to project root
│   │                          # - Prints a short summary to the terminal
│   │
│
├── templates/
│   └── report.html.j2       # Jinja2 template for the HTML report:
│                             # - Header with target and timestamp
│                             # - Summary count of reflections found
│                             # - A block per finding with parameter, context, payload, snippet
│
├── main.py                  # Example entry point:
│                             # - Shows how to construct XSSScanner (url, parameters, method)
│                             # - Calls scanner.scan() to run the scan and produce the report
│
├── requirements.txt         # Python dependencies:
│                             # - requests
│                             # - beautifulsoup4
│                             # - lxml
│                             # - jinja2
│                             
├── readme.md                # Documentation 
└── vipratech_report.html    # Output file produced after a scan

## 2. How the PayloadGenerator Chooses Payloads

    The PayloadGenerator groups payloads based on **HTML context**, because XSS behaves differently depending on where user input appears.

### Contexts handled:
    - **Text context**
    - **Attribute value context**
    - **Attribute name context**
    - **JavaScript string context**
    - **Tag-injection context**

    Every payload contains a unique marker to help detection.

    The scanner simply runs all payloads for all contexts — the detector later identifies where it was reflected.

## 3. Reflection Detection Logic (ReflectionDetector)

    1. Check if the unique marker appears in the HTML response.
    2. If it appears, capture a small snippet around it.
    3. Use BeautifulSoup to understand **where** it appeared:
    - inside `<script>` → JavaScript context  
    - inside attribute value  
    - inside attribute name  
    - inside text  
    - inside a tag  
    4. Classify and save the results.
    5. Use Jinja2 to render an HTML report.

## 4. Setup & Run

### Create virtual environment
Windows:
    python -m venv renv
    renv\Scripts\activate   # to activate

### Install packages

    pip install -r requirements.txt


### Running the scanner
    Edit URL and parameters in `main.py`, then run:

      by the command -> python main.py

### Report
  It generates:
     vipratech_report.html   ---> Open it in your browser.

## 5. Code Design Choices

    - Each module has a single purpose (payloads, detector, report, scanner).
    - Payloads are grouped by context for clarity.
    - Marker-based detection keeps false positives low.
    - Threading is added for speed without complexity.
    - HTML report is cleaner than raw terminal output.
    - Code is simple and maintainable as required.

