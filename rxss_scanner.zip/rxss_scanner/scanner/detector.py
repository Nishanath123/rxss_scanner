# scanner/detector.py
import re
from bs4 import BeautifulSoup

class ReflectionDetector:
    def __init__(self, marker: str):
        self.marker = marker

    def is_reflected(self, html: str, payload: str) -> dict:
        if self.marker not in html:
            return {"reflected": False}

        pos = html.find(self.marker)
        snippet = html[max(0, pos-100):pos+100]
        context = self._guess_context(snippet, payload)

        return {
            "reflected": True,
            "payload": payload,
            "context": context,
            "snippet": snippet.replace(self.marker, f"[{self.marker}]"),
            "position": pos
        }

    def _guess_context(self, snippet: str, payload: str) -> str:
        soup = BeautifulSoup(snippet, "lxml")
        marker_node = soup.find(string=re.compile(re.escape(self.marker)))
        if not marker_node:
            return "javascript"

        parent = marker_node.parent

        # JS context
        if parent and parent.name == "script":
            return "js_string"

        # Attribute name context
        if parent and any(self.marker in attr for attr in parent.attrs.keys()):
            return "attribute_name"

        # Attribute value
        if parent and parent.attrs and any(self.marker in str(v) for v in parent.attrs.values()):
            return "attribute_value"

        # Tag name injection
        if payload.lstrip().startswith("<") and marker_node in parent.find_all(string=True):
            return "tag_name"

        return "text"