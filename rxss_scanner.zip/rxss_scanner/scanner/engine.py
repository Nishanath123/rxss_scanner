# scanner/engine.py
import requests
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlencode
from .payloads import PayloadGenerator
from .detector import ReflectionDetector
from .reporter import generate_html_report, print_summary

class XSSScanner:
    def __init__(self, url: str, parameters: list, method: str = "GET", threads: int = 15,
                 headers=None, cookies=None):
        self.url = url.rstrip("/")
        self.params = parameters
        self.method = method.upper()
        self.headers = headers or {}
        self.cookies = cookies or {}
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        self.session.cookies.update(self.cookies)

        self.pg = PayloadGenerator()
        self.detector = ReflectionDetector(self.pg.get_marker())
        self.vulnerabilities = []

    def _send_request(self, param: str, payload: str):
        try:
            if self.method == "GET":
                test_url = f"{self.url}?{urlencode({param: payload})}"
                r = self.session.get(test_url, timeout=10)
            else:
                r = self.session.post(self.url, data={param: payload}, timeout=10)

            result = self.detector.is_reflected(r.text, payload)
            if result["reflected"]:
                self.vulnerabilities.append({
                    "param": param,
                    "payload": payload,
                    "context": result["context"],
                    "snippet": result["snippet"],
                    "url": r.url
                })
                print(f"[+] VULN → {param} [{result['context']}]")
        except Exception as e:
            pass  # Silent fail per request

    def scan(self):
        print(f"[*] Starting scan on {self.url} → {len(self.params)} parameters")
        payloads = self.pg.all_payloads()

        with ThreadPoolExecutor(max_workers=15) as executor:
            for param in self.params:
                for payload in payloads:
                    executor.submit(self._send_request, param, payload)

        generate_html_report(self.vulnerabilities, self.url)
        print_summary(self.vulnerabilities, self.url)