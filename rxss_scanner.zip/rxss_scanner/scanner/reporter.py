# scanner/reporter.py
from jinja2 import Environment, FileSystemLoader
from datetime import datetime

def generate_html_report(findings: list, target_url: str, output_file: str = "vipratech_report.html"):
    env = Environment(loader=FileSystemLoader("templates"))
    template = env.get_template("report.html.j2")
    html = template.render(
        target=target_url,
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        findings=findings,
        total=len(findings)
    )
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"\n[+] HTML report saved → {output_file}")

def print_summary(findings: list, url: str):
    print("\n" + "="*70)
    print(f"Target: {url}")
    print(f"Total Reflections Found: {len(findings)}")
    print("="*70)
    for f in findings:
        print(f"Param: {f['param']:<15} Context: {f['context']:<18} Payload: {f['payload'][:60]}")